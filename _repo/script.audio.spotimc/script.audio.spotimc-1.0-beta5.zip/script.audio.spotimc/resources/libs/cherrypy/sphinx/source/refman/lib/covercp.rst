***************************
:mod:`cherrypy.lib.covercp`
***************************

.. automodule:: cherrypy.lib.covercp

Classes
=======

.. autoclass:: CoverStats
   :members:

Functions
=========

.. autofunction:: get_tree

.. autofunction:: serve
