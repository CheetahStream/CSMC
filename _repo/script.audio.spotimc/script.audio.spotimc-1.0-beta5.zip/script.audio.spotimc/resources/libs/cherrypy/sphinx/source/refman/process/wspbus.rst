**********************************************************
:mod:`cherrypy.process.wspbus` -- The Web Site Process Bus
**********************************************************

.. automodule:: cherrypy.process.wspbus

Classes
=======

.. autoclass:: ChannelFailures
   :members:

.. autoclass:: Bus
   :members:

