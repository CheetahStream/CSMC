*************************
:mod:`cherrypy._cpconfig`
*************************

.. automodule:: cherrypy._cpconfig

Classes
=======

.. autoclass:: Config
   :members:
   :inherited-members:

Functions
=========

.. autofunction:: merge

